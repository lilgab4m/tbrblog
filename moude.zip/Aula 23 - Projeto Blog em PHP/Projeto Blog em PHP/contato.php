<?php
  include_once("templates/header.php");
?>
  <h1>Página de contato</h1>
<?php
  include_once("templates/footer.php")
?>